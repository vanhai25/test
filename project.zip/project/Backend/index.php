<?php 
if(!isset($_SESSION['user_admin']) && empty($_SESSION['user_admin'])){

}
require_once '../App/Config/config.php';

require_once '../App/Controllers/BaseController.php';
require_once '../Libs/functions.php';



if($_SERVER['REQUEST_METHOD'] === 'GET'){
	if(isset($_GET['com']) && !empty($_GET['com'])){
		$controllerName = htmlspecialchars($_GET['com'], ENT_QUOTES, 'UTF-8');
	}
	else{
		$controllerName = 'DashboardController';
	}

	if(isset($_GET['act']) && !empty($_GET['act'])){
		$actionName = htmlspecialchars($_GET['act'], ENT_QUOTES, 'UTF-8');
	}
	else{
		$actionName = 'index';
	}
}

require_once "../App/Controllers/Backend/${controllerName}.php";

$controllerObject = new $controllerName;

$controllerObject->$actionName();

?>