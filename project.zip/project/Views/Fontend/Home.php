<?php 
echo createToken(40);
?>