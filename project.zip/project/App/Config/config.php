<?php 

define('BASE_URL', 'http://localhost/git/project/');





?>