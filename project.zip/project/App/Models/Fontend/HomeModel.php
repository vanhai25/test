<?php 
class HomeModel extends DBConnect{
	public function getall(){
		
	}
}
?>