<?php 
class BaseController{
	protected const VIEW_FONTEND = 'Views';
	protected const MODEL_FONTEND = 'App/Models';

	protected const VIEW_BACKEND = '../Views';
	protected const MODEL_BACKEND ='../App/Model';

	protected $check = 'check';

	

	public function View($path,string $check = null, array $data = [] ){

		foreach($data as $key => $value){
			$$key = $value;
		}
		if($check == ''){
			return require(self::VIEW_FONTEND.'/'.str_replace('.', '/', $path).'.php');
		}
		else{
			return require(self::VIEW_BACKEND.'/'.str_replace('.', '/', $path).'.php');
		}

		
	} 

	public function Model($path,string $check = null){
		if($check == ''){
			return require(self::MODEL_FONTEND.'/'.str_replace('.', '/', $path).'.php');
		}
		else{
			return require(self::MODEL_BACKEND.'/'.str_replace('.', '/', $path).'.php');
		}
		
	}
}

?>