<?php 
class DashboardController extends BaseController{

	public function index(){


		return $this->View('Backend.Dashboard.index',$this->check,[
			'tt' => 'a',
		]);

	}
	
}
?>