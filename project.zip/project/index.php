<?php 
require_once 'App/Controllers/BaseController.php';
require_once 'App/Core/DBConnect.php';
require_once 'Libs/functions.php';


if($_SERVER['REQUEST_METHOD'] === 'GET'){
	if(isset($_GET['c']) && !empty($_GET['c'])){
		$controllerName = htmlspecialchars($_GET['c'], ENT_QUOTES, 'UTF-8');
	}
	else{
		$controllerName = 'HomeController';
	}

	if(isset($_GET['action']) && !empty($_GET['action'])){
		$actionName = htmlspecialchars($_GET['action'], ENT_QUOTES, 'UTF-8');
	}
	else{
		$actionName = 'index';
	}
}


require_once "app/Controllers/Fontend/${controllerName}.php";

$controllerObject = new $controllerName;

$controllerObject->$actionName();



?>